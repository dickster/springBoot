package com.brovada;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.inject.Inject;



@SpringBootApplication
public class Application implements CommandLineRunner {

	@Inject
	private QuoteRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		repository.deleteAll();

		repository.save(new Quote("Alice", "Smith"));
		repository.save(new Quote("Bob", "Smith"));
		repository.save(new Quote("Bill", "Jones"));
		repository.save(new Quote("John", "Doe"));
		repository.save(new Quote("Sally", "Smith"));
		repository.save(new Quote("Alice", "Hearth"));


        System.out.println("Quotes found with findAll():");
        System.out.println("-------------------------------");
        for (Quote quote : repository.findAll()) {
            System.out.println(quote);
        }
        System.out.println();

	}

}
